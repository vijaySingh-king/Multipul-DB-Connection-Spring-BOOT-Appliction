package com.kindsonthegenius.epm2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Epm2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
